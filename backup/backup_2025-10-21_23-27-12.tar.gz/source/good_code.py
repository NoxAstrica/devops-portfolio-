"""Good code example for lint testing."""

def greet(name):
    """Return a greeting for the given name."""
    return f"Hello, {name}!"

if __name__ == "__main__":
    print(greet("World"))

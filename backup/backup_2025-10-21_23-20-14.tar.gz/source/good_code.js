function greet(name) {
  console.log(`Hey, ${name}!`);
}

greet("You");
